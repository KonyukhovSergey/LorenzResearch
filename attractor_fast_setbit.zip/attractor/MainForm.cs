﻿/*
 * Created by SharpDevelop.
 * User: serjik
 * Date: 06.09.2014
 * Time: 0:44
 * 
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace attractor
{
	public partial class MainForm : Form
	{
		[DllImport("gdi32")]
		private extern static int SetDIBitsToDevice(HandleRef hDC, int xDest, int yDest, int dwWidth, int dwHeight, int XSrc, int YSrc, int uStartScan, int cScanLines, ref int lpvBits, ref BITMAPINFO lpbmi, uint fuColorUse);

		[StructLayout(LayoutKind.Sequential)]
		private struct BITMAPINFOHEADER
		{
			public int bihSize;
			public int bihWidth;
			public int bihHeight;
			public short	bihPlanes;
			public short	bihBitCount;
			public int bihCompression;
			public int bihSizeImage;
			public double	bihXPelsPerMeter;
			public double	bihClrUsed;
		}

		[StructLayout(LayoutKind.Sequential)]
		private struct BITMAPINFO
		{
			public BITMAPINFOHEADER biHeader;
			public int biColors;
		}

		private GCHandle _gcHandle;
		private BITMAPINFO _BI;

		private void Realloc()
		{
			if (_gcHandle.IsAllocated)
				_gcHandle.Free();

			_gcHandle = GCHandle.Alloc(scr, GCHandleType.Pinned);
			_BI = new BITMAPINFO {
				biHeader = {
					bihBitCount = 32,
					bihPlanes = 1,
					bihSize = 40,
					bihWidth = width,
					bihHeight = -height,
					bihSizeImage = (width * height) << 2
				}
			};
		}

		
		private Bitmap bmp;
		private Graphics gr;
		
		private int[] scr;
		private int width, height;
		
		private Random rnd = new Random(Environment.TickCount);
		private volatile bool isWork = true;
		
		public MainForm()
		{
			InitializeComponent();
			
			SetStyle(ControlStyles.DoubleBuffer, false);
			SetStyle(ControlStyles.UserPaint, true);
			SetStyle(ControlStyles.AllPaintingInWmPaint, true);
			SetStyle(ControlStyles.Opaque, true);
			
			Task task = Task.Factory.StartNew(() =>
			{
				Thread.Sleep(100);
				Invalidate();
				Thread.Sleep(100);
				
				while (isWork)
				{
					OnDraw();
//					Invalidate();
					//Thread.Sleep(40);
				}
			});
			
		}
		
		protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
		{
			isWork = false;
			base.OnClosing(e);
		}
		
		protected override void OnKeyUp(KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Escape)
			{
				Close();
			}
			base.OnKeyDown(e);
		}
		
		
		private void OnDraw()
		{
			for (int i = 0; i < scr.Length; i++)
			{
				//scr[i] = (scr[i] & 0x00fefefe) >> 1;
				scr[i] = scr[i] > 0 ? scr[i] - 1 : 0;
			}
			
			for (int i = 0; i < 100; i++)
			{
				scr[rnd.Next() % (width * height)] = 0xff;
			}
		}
		
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			//base.OnPaintBackground(e);
		}
		
		private int frames = 0;
		private long ticks = Environment.TickCount;
		private HandleRef hDCRef;
		
		protected override void OnPaint(PaintEventArgs e)
		{
			if (scr == null)
			{
				width = ClientSize.Width;
				height = ClientSize.Height;
//				bmp = new Bitmap(width, height, PixelFormat.Format32bppRgb);
//				gr = Graphics.FromImage(bmp);
				scr = new int[width * height];
				Graphics hDCGraphics = CreateGraphics();
				hDCRef = new HandleRef(hDCGraphics, hDCGraphics.GetHdc());
				//hDCRef = new HandleRef(e.Graphics, e.Graphics.GetHdc());
				Realloc();
			}
			
			
//			BitmapData bd = bmp.LockBits(ClientRectangle, ImageLockMode.ReadWrite, PixelFormat.Format32bppRgb);
//			
//			Marshal.Copy(scr, 0, bd.Scan0, scr.Length);
//			
//			bmp.UnlockBits(bd);
			
			//e.Graphics.DrawImage(bmp, 0, 0);
			SetDIBitsToDevice(hDCRef, 0, 0, width, height, 0, 0, 0, height, ref scr[0], ref _BI, 0);

		
			frames++;
			
			if (Environment.TickCount - ticks > 1000)
			{
				Text = "fps = " + frames.ToString();
				ticks = Environment.TickCount;
				frames = 0;
			}
			//OnDraw();
			Invalidate();
		}
		
		protected override void OnSizeChanged(EventArgs e)
		{
			if (scr != null)
			{
				scr = null;
			}
			if (bmp != null)
			{
				gr.Dispose();
				bmp.Dispose();
				bmp = null;
				
			}
			base.OnSizeChanged(e);
		}
	}
	
	
}
